# Student-Mangement-SMS-ALERT
This project is open source, it's able to store student data and also send sms to phone, about there fees, admission and their behaviour.
